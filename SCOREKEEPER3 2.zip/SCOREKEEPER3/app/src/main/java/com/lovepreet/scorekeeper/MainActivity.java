package com.lovepreet.scorekeeper;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.os.Bundle;
        import android.preference.PreferenceManager;
        import android.text.Editable;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.Button;
        import android.widget.RadioGroup;
        import android.widget.TextView;
        import android.widget.Toast;

        import org.w3c.dom.Text;

        import java.util.function.Predicate;
        import java.util.prefs.AbstractPreferences;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, View.OnClickListener {
    private TextView teamScoreRedTextView;
    private TextView teamScoreBlueTextView;

    private int incrementBy;
    private int teamRedScore;
    private int teamBlueScore;


    private SharedPreferences prefs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        boolean save = prefs.getBoolean("save_score_pre", false);
        String scores = prefs.getString("scores_pref", "default");
        Toast.makeText(this, Boolean.toString(save), Toast.LENGTH_SHORT).show();
        teamRedScore = 0;
        teamBlueScore = 0;

        //finding all the views by ids, refer to the xml page for the ids,
        //the names are self explanatory
        RadioGroup radioGroup = findViewById(R.id.radio_group);

        teamScoreRedTextView = findViewById(R.id.team_score_red);
        teamScoreBlueTextView = findViewById(R.id.team_score_blue);

        teamScoreBlueTextView.setText(Integer.toString(teamBlueScore));
        teamScoreRedTextView.setText(Integer.toString(teamRedScore));

        Button upButtonRed = findViewById(R.id.buttonUp_red);
        Button downButtonRed = findViewById(R.id.buttonDown_red);
        Button upButtonBlue = findViewById(R.id.buttonUp_blue);
        Button downButtonBlue = findViewById(R.id.buttonDown_blue);

        //setting onClickListeners for these vie
        radioGroup.setOnCheckedChangeListener(this);
        upButtonRed.setOnClickListener(this);
        downButtonRed.setOnClickListener(this);
        upButtonBlue.setOnClickListener(this);
        downButtonBlue.setOnClickListener(this);
    }

    @Override
    //selecting the increment value using the radio button
    public void onCheckedChanged(RadioGroup radioGroup, int i) {

        switch (i) {
            case 1:
                incrementBy = 1;
                break;
            case 2:
                incrementBy = 2;
                break;
            case 3:
                incrementBy = 3;
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menus, menu);
        return true;
    }

    // saving data on pause
   protected void onPause() {
      saveData();
      super.onPause();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.about) {
            Toast.makeText(this, "Name:Lovepreet Kaur,Student Id:A00238391", Toast.LENGTH_LONG).show();
            return true;
        } else if (itemId == R.id.setting) {
            startActivity(new Intent(
                    getApplicationContext(), Settings.class
            ));
            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        //according to the buttons clicked the respective functions are performed
        switch (id) {
            case R.id.buttonUp_blue:
                teamBlueScore += incrementBy;
                teamScoreBlueTextView.setText(Integer.toString(teamBlueScore));
                break;
            case R.id.buttonDown_blue:
                teamBlueScore -= incrementBy;
                teamScoreBlueTextView.setText(Integer.toString(teamBlueScore));
                break;
            case R.id.buttonUp_red:
                teamRedScore += incrementBy;
                teamScoreRedTextView.setText(Integer.toString(teamRedScore));
                break;
            case R.id.buttonDown_red:
                teamRedScore -= incrementBy;
                teamScoreRedTextView.setText(Integer.toString(teamRedScore));
                break;
        }
    }

    private void saveData() {
        SharedPreferences.Editor editor = prefs.edit();
        if (prefs.getBoolean("save_score_pre", false)) {

            TextView scoreR = findViewById(R.id.team_score_red);
            TextView scoreB = findViewById(R.id.team_score_blue);
           editor.putInt("redTeamScore", Integer.parseInt(scoreR.getText().toString()));
            editor.putInt("blueTeamScore", Integer.parseInt(scoreB.getText().toString()));

           RadioGroup choiceOfScores = findViewById(R.id.radio_group);
           int scoresNum = 0, scoresId = choiceOfScores.getCheckedRadioButtonId();
            if (scoresId == R.id.incrementByOne) {
              scoresNum = 1;
            } else if (scoresId == R.id.incrementByTwo) {
                scoresNum = 2;
           } else if (scoresId == R.id.incrementByThree) {
               scoresNum = 3;
            }

           editor.putInt("scoresNum", scoresNum);

       }
        editor.apply();
    }
}


